package com.exercicio1.exercicio

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
